/**
 * Auth Domain
 *
 * Authentication features, forms, and social auth providers.
 *
 * DO NOT export from this file - always import explicitly from submodules
 */
