/**
 * Privacy Policy UI Components
 */

export { PrivacyContent } from "./privacy-content";
