/**
 * Privacy Feature Components
 */

export { PrivacyPage } from "./privacy-page";
