/**
 * Client-side data access exports for profile domain
 *
 * Note: Profile domain currently has no client-side hooks
 * All data fetching is done server-side
 */

// No client-side exports yet
