/**
 * Server-side data access exports for profile domain
 */

export * from "./get-user-profile";
