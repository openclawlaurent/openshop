/**
 * Client-side data access exports for earnings domain
 * All business logic has been moved to server-side
 */
