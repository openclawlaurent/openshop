/**
 * Terms Feature Components
 */

export { TermsPage } from "./terms-page";
