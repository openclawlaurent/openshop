/**
 * Admin Domain
 *
 * Admin dashboard features and actions.
 *
 * DO NOT export from this file - always import explicitly from submodules
 */
