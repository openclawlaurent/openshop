/**
 * Analytics Domain
 *
 * Analytics tracking, PostHog integration, and Intercom chat.
 *
 * DO NOT export from this file - always import explicitly from submodules
 */
