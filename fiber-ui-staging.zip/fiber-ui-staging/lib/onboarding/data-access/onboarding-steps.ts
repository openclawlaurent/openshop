/**
 * Onboarding step IDs
 */
export const ONBOARDING_STEPS = {
  WELCOME: 1,
  HOW_IT_WORKS: 2,
  SETUP: 3,
} as const;
