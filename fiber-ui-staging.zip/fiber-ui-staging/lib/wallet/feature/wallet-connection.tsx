"use client";

import { WalletConnectionContentV4 } from "./wallet-connection-content-v4";

export function WalletConnection() {
  return <WalletConnectionContentV4 />;
}
