/**
 * FAQ Feature Components
 */

export { FaqPage } from "./faq-page";
