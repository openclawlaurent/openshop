export * from "./waitlist-page";
