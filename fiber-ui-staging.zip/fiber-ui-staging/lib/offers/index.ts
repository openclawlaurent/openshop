/**
 * Offers Domain
 *
 * Handles offer management, display, and filtering.
 *
 * DO NOT export from this file - always import explicitly from submodules
 */
