/**
 * Server-side data access exports
 * ONLY import these in Server Components
 */
export { getOffersSSR } from "../offers";
