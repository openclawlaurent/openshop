/**
 * Navigation Domain
 *
 * App navigation shell, sidebar, and navigation items.
 *
 * DO NOT export from this file - always import explicitly from submodules
 */
