/**
 * Server-side data access exports for search domain
 */

export * from "./get-search-results";
