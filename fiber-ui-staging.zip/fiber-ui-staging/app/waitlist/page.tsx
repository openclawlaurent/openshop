import { WaitlistPage } from "@/lib/waitlist/feature";

export default function Waitlist() {
  return <WaitlistPage />;
}
