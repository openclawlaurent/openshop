import { MerchantFilterAdmin } from "@/lib/admin/ui";

export default function MerchantFiltersPage() {
  return <MerchantFilterAdmin />;
}
