import { CacheActions } from "@/lib/admin/ui";

export default function CachePage() {
  return <CacheActions />;
}
