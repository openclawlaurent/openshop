import { SignUpForm } from "@/lib/auth/feature";

export default function SignUp() {
  return <SignUpForm />;
}
